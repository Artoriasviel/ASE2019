
for impl_name in RINGBUFFER STACK SLIST DLIST DEQUE
do
    printf "\n\n\n%s\tT1\tT2\tT3\tT4\tT5\tT6\tT7\tT8\tT9\tT10\n" $impl_name
    timeline=`cat SEQUENTIAL_${impl_name}.txt| grep "Throughput" | awk '{print $2}'`
    for t in $timeline
    do
        printf "%.3f\t"  $t
    done
    printf "\n"
done


