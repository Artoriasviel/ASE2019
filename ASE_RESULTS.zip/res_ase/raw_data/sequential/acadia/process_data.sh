
printf "\n\n\n\tT1\tT2\tT3\tT4\tT5\tT6\tT7\tT8\tT9\tT10\n"
for impl_name in RINGBUFFER STACK SLIST DLIST DEQUE
do
    printf "%s\t" SEQUENTIAL_${impl_name}
    timeline=`cat SEQUENTIAL_${impl_name}.txt| grep "Throughput" | awk '{print $2}'`
    for t in $timeline
    do
        printf "%.3f\t"  $t
    done
    printf "\n"
done

for impl_name in HASHSET BST MDLIST
do
    printf "%s\t" SEQUENTIAL_${impl_name}_WRITE
    timeline=`cat SEQUENTIAL_${impl_name}.txt.write_only| grep "Throughput" | awk '{print $2}'`
    for t in $timeline
    do
        printf "%.3f\t"  $t
    done
    printf "\n"
done

for impl_name in HASHSET BST MDLIST
do
    printf "%s\t" SEQUENTIAL_${impl_name}_READ
    timeline=`cat SEQUENTIAL_${impl_name}.txt.mostly_read| grep "Throughput" | awk '{print $2}'`
    for t in $timeline
    do
        printf "%.3f\t"  $t
    done
    printf "\n"
done

